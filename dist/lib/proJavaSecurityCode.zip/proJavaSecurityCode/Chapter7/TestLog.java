public class TestLog {
	public static void main (String[] args) {
// CHANGED
		Log.logAction("This is a test.");
	}
}