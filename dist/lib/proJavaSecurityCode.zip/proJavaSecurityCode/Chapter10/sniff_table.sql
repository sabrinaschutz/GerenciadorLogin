

create table sniff_table (
	secret_id			INT,
	credit_card			VARCHAR(20)
);

insert into sniff_table (secret_id, credit_card) VALUES (0, '123-123-123');
insert into sniff_table (secret_id, credit_card) VALUES (1, '123-123-123');
insert into sniff_table (secret_id, credit_card) VALUES (2, '123-123-123');
insert into sniff_table (secret_id, credit_card) VALUES (3, '123-123-123');
insert into sniff_table (secret_id, credit_card) VALUES (4, '123-123-123');
