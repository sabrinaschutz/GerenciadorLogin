/**
 * @(#) Proxy.java
 */

package com.isnetworks.remote;

/**
 * Interface for proxy objects
 * @author Daniel R. Somerfield
 * @version 1.0
 */
import java.io.Serializable;
public interface Proxy extends Serializable {

}
