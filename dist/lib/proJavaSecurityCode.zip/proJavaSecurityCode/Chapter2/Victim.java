public class Victim {

	private String secret;

	public Victim() {
		secret = "squeamish ossifrage";
	}
}