public class Perpetrator {

	public static void main (String[] args) {
		Victim victim = new Victim();
		System.out.println(victim.secret);
	}
}